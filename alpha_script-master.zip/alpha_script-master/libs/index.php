<?php 
header('Location: /');
 ?>